package com.example.iosclock.ui

import android.content.Context
import android.os.SystemClock
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.iosclock.alarm.AlarmScheduler
import kotlinx.coroutines.delay
import java.text.DateFormat
import java.util.Date

enum class TimerStatus { Idle, Running, Paused }

/** Process-wide timer state; the end-of-timer notification is delivered by AlarmManager. */
object TimerEngine {
    var status by mutableStateOf(TimerStatus.Idle)
    var totalMs by mutableLongStateOf(0L)
    private var endAt = 0L
    private var pausedRemaining = 0L
    private var endWallClock = 0L

    fun remaining(): Long = when (status) {
        TimerStatus.Running -> (endAt - SystemClock.elapsedRealtime()).coerceAtLeast(0L)
        TimerStatus.Paused -> pausedRemaining
        TimerStatus.Idle -> 0L
    }

    val endsAtWallClock: Long get() = endWallClock

    fun start(c: Context, ms: Long) {
        totalMs = ms
        run(c, ms)
    }

    private fun run(c: Context, ms: Long) {
        endAt = SystemClock.elapsedRealtime() + ms
        endWallClock = System.currentTimeMillis() + ms
        status = TimerStatus.Running
        AlarmScheduler.scheduleTimer(c, endWallClock)
    }

    fun pause(c: Context) {
        pausedRemaining = remaining()
        status = TimerStatus.Paused
        AlarmScheduler.cancelTimer(c)
    }

    fun resume(c: Context) = run(c, pausedRemaining)

    fun cancel(c: Context) {
        status = TimerStatus.Idle
        AlarmScheduler.cancelTimer(c)
    }

    /** Called by the UI when the countdown reaches zero while visible. */
    fun finish() {
        status = TimerStatus.Idle
    }
}

private fun formatCountdown(ms: Long): String {
    val totalSec = (ms + 999) / 1000
    val h = totalSec / 3600
    val m = (totalSec / 60) % 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}

@Composable
fun TimerScreen() {
    val ctx = LocalContext.current
    var hours by remember { mutableIntStateOf(0) }
    var minutes by remember { mutableIntStateOf(1) }
    var seconds by remember { mutableIntStateOf(0) }
    var remaining by remember { mutableLongStateOf(TimerEngine.remaining()) }
    val status = TimerEngine.status

    LaunchedEffect(status) {
        remaining = TimerEngine.remaining()
        while (TimerEngine.status == TimerStatus.Running) {
            delay(50)
            remaining = TimerEngine.remaining()
            if (remaining <= 0L) TimerEngine.finish()
        }
    }

    Column(Modifier.fillMaxSize().padding(top = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp), contentAlignment = Alignment.Center) {
            if (status == TimerStatus.Idle) {
                Row(Modifier.fillMaxWidth()) {
                    WheelPicker(0..23, hours, { hours = it }, Modifier.weight(1f), suffix = "hours")
                    WheelPicker(0..59, minutes, { minutes = it }, Modifier.weight(1f), suffix = "min")
                    WheelPicker(0..59, seconds, { seconds = it }, Modifier.weight(1f), suffix = "sec")
                }
            } else {
                val progress = if (TimerEngine.totalMs > 0) remaining.toFloat() / TimerEngine.totalMs else 0f
                Box(Modifier.size(300.dp), contentAlignment = Alignment.Center) {
                    Canvas(Modifier.fillMaxSize()) {
                        val stroke = 10.dp.toPx()
                        val inset = stroke / 2
                        val arcSize = Size(size.width - stroke, size.height - stroke)
                        drawArc(
                            IosDarkGray, 0f, 360f, false,
                            topLeft = Offset(inset, inset), size = arcSize, style = Stroke(stroke),
                        )
                        drawArc(
                            IosOrange, -90f, 360f * progress, false,
                            topLeft = Offset(inset, inset), size = arcSize,
                            style = Stroke(stroke, cap = StrokeCap.Round),
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            formatCountdown(remaining),
                            color = Color.White,
                            style = TextStyle(fontSize = 64.sp, fontWeight = FontWeight.Light, fontFeatureSettings = "tnum"),
                        )
                        if (status == TimerStatus.Running) {
                            Text(
                                "Ends " + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(TimerEngine.endsAtWallClock)),
                                color = IosGray, fontSize = 17.sp,
                            )
                        } else {
                            Text("Paused", color = IosGray, fontSize = 17.sp)
                        }
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 32.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
        ) {
            when (status) {
                TimerStatus.Idle -> {
                    val total = (hours * 3600L + minutes * 60L + seconds) * 1000L
                    CircleButton("Cancel", IosDarkGray, Color.White, enabled = false) { }
                    CircleButton("Start", IosGreenBg, IosGreen, enabled = total > 0) {
                        TimerEngine.start(ctx, total)
                    }
                }
                TimerStatus.Running -> {
                    CircleButton("Cancel", IosDarkGray, Color.White) { TimerEngine.cancel(ctx) }
                    CircleButton("Pause", Color(0xFF3D2A05), IosOrange) { TimerEngine.pause(ctx) }
                }
                TimerStatus.Paused -> {
                    CircleButton("Cancel", IosDarkGray, Color.White) { TimerEngine.cancel(ctx) }
                    CircleButton("Resume", IosGreenBg, IosGreen) { TimerEngine.resume(ctx) }
                }
            }
        }
    }
}
