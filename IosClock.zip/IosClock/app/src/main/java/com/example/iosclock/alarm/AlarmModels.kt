package com.example.iosclock.alarm

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** days uses java.util.Calendar.DAY_OF_WEEK values (1 = Sunday .. 7 = Saturday). Empty = one-shot. */
data class AlarmItem(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val label: String = "Alarm",
    val days: Set<Int> = emptySet(),
    val enabled: Boolean = true,
)

object AlarmStore {
    private const val PREFS = "alarms"
    private const val KEY = "list"

    fun load(c: Context): List<AlarmItem> {
        val raw = c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val arr = JSONArray(raw)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            val d = o.getJSONArray("days")
            AlarmItem(
                id = o.getInt("id"),
                hour = o.getInt("h"),
                minute = o.getInt("m"),
                label = o.optString("label", "Alarm"),
                days = (0 until d.length()).map { d.getInt(it) }.toSet(),
                enabled = o.optBoolean("on", true),
            )
        }
    }

    fun save(c: Context, list: List<AlarmItem>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().apply {
                put("id", it.id)
                put("h", it.hour)
                put("m", it.minute)
                put("label", it.label)
                put("days", JSONArray(it.days.toList()))
                put("on", it.enabled)
            })
        }
        c.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun newId(): Int = (System.currentTimeMillis() and 0x7fffffff).toInt().coerceAtLeast(2000)
}
