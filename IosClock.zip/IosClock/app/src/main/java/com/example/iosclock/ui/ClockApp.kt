package com.example.iosclock.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Bed
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector

private data class Tab(val title: String, val icon: ImageVector)

private val tabs = listOf(
    Tab("World Clock", Icons.Filled.Public),
    Tab("Alarm", Icons.Filled.Alarm),
    Tab("Bedtime", Icons.Filled.Bed),
    Tab("Stopwatch", Icons.Filled.Timer),
    Tab("Timer", Icons.Filled.HourglassBottom),
)

@Composable
fun ClockApp() {
    var selected by rememberSaveable { mutableIntStateOf(0) }
    Scaffold(
        containerColor = IosBg,
        contentWindowInsets = WindowInsets(0),
        bottomBar = {
            NavigationBar(containerColor = IosBg) {
                tabs.forEachIndexed { i, t ->
                    NavigationBarItem(
                        selected = selected == i,
                        onClick = { selected = i },
                        icon = { Icon(t.icon, contentDescription = t.title) },
                        label = { Text(t.title, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = IosOrange,
                            selectedTextColor = IosOrange,
                            unselectedIconColor = IosGray,
                            unselectedTextColor = IosGray,
                            indicatorColor = IosBg,
                        ),
                    )
                }
            }
        },
    ) { pad ->
        Box(Modifier.fillMaxSize().background(IosBg).padding(pad)) {
            when (selected) {
                0 -> WorldClockScreen()
                1 -> AlarmScreen()
                2 -> BedtimeScreen()
                3 -> StopwatchScreen()
                else -> TimerScreen()
            }
        }
    }
}
