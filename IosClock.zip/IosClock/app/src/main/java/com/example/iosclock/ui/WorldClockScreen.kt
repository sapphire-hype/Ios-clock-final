package com.example.iosclock.ui

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale
import kotlin.math.abs

private object CityStore {
    private val defaults = listOf("America/Los_Angeles", "Europe/London", "Asia/Tokyo")

    fun load(c: Context): List<String> {
        val s = c.getSharedPreferences("cities", Context.MODE_PRIVATE).getString("zones", null)
        return s?.split(",")?.filter { it.isNotBlank() } ?: defaults
    }

    fun save(c: Context, zones: List<String>) {
        c.getSharedPreferences("cities", Context.MODE_PRIVATE).edit()
            .putString("zones", zones.joinToString(",")).apply()
    }
}

private fun cityName(id: String) = id.substringAfterLast('/').replace('_', ' ')

private val allZones: List<String> by lazy {
    val prefixes = listOf("Africa/", "America/", "Asia/", "Atlantic/", "Australia/", "Europe/", "Indian/", "Pacific/")
    ZoneId.getAvailableZoneIds().filter { id -> prefixes.any { id.startsWith(it) } }
        .sortedBy { cityName(it) }
}

private val timeFmt = DateTimeFormatter.ofPattern("h:mm", Locale.US)
private val ampmFmt = DateTimeFormatter.ofPattern("a", Locale.US)

private fun relativeLabel(now: ZonedDateTime, zone: ZoneId): String {
    val local = now.withZoneSameInstant(ZoneId.systemDefault())
    val there = now.withZoneSameInstant(zone)
    val dayDiff = there.toLocalDate().toEpochDay() - local.toLocalDate().toEpochDay()
    val day = when {
        dayDiff == 0L -> "Today"
        dayDiff == 1L -> "Tomorrow"
        dayDiff == -1L -> "Yesterday"
        else -> there.format(DateTimeFormatter.ofPattern("EEE", Locale.US))
    }
    val diffMin = (there.offset.totalSeconds - local.offset.totalSeconds) / 60
    val sign = if (diffMin < 0) "-" else "+"
    val h = abs(diffMin) / 60
    val m = abs(diffMin) % 60
    val amount = if (m == 0) "$h${if (h == 1) "HR" else "HRS"}" else "$h:${"%02d".format(m)}HRS"
    return "$day, $sign$amount"
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WorldClockScreen() {
    val ctx = LocalContext.current
    var zones by remember { mutableStateOf(CityStore.load(ctx)) }
    var editing by remember { mutableStateOf(false) }
    var adding by remember { mutableStateOf(false) }
    var now by remember { mutableStateOf(ZonedDateTime.now()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = ZonedDateTime.now()
            delay(1000)
        }
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(
            title = "World Clock",
            left = { OrangeTextButton(if (editing) "Done" else "Edit") { editing = !editing } },
            right = {
                IconButton(onClick = { adding = true }) {
                    Icon(Icons.Filled.Add, contentDescription = "Add city", tint = IosOrange)
                }
            },
        )
        HorizontalDivider(color = IosSep, modifier = Modifier.padding(top = 8.dp))
        LazyColumn(Modifier.fillMaxWidth()) {
            items(zones, key = { it }) { id ->
                val zone = ZoneId.of(id)
                val t = now.withZoneSameInstant(zone)
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (editing) {
                        Box(
                            Modifier.size(24.dp).background(IosRed, CircleShape).clickable {
                                zones = zones - id
                                CityStore.save(ctx, zones)
                            },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Filled.Remove, null, tint = Color.White, modifier = Modifier.size(16.dp))
                        }
                        Box(Modifier.size(12.dp))
                    }
                    Column(Modifier.weight(1f)) {
                        Text(relativeLabel(now, zone), color = IosGray, fontSize = 14.sp)
                        Text(cityName(id), color = Color.White, fontSize = 24.sp)
                    }
                    Text(
                        t.format(timeFmt),
                        color = Color.White,
                        style = TextStyle(fontSize = 52.sp, fontWeight = FontWeight.Light, fontFeatureSettings = "tnum"),
                    )
                    Text(
                        " " + t.format(ampmFmt),
                        color = Color.White,
                        fontSize = 22.sp,
                        modifier = Modifier.padding(top = 18.dp),
                    )
                }
                HorizontalDivider(color = IosSep)
            }
        }
    }

    if (adding) {
        var query by remember { mutableStateOf("") }
        ModalBottomSheet(
            onDismissRequest = { adding = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = IosCard,
        ) {
            Column(Modifier.fillMaxWidth().height(520.dp)) {
                Text(
                    "Choose a City",
                    color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 8.dp),
                )
                TextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Search", color = IosGray) },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = IosDarkGray,
                        unfocusedContainerColor = IosDarkGray,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                    ),
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                )
                val filtered = allZones.filter { cityName(it).contains(query.trim(), ignoreCase = true) }
                LazyColumn(Modifier.fillMaxWidth()) {
                    items(filtered, key = { it }) { id ->
                        Text(
                            cityName(id) + "  ·  " + id.substringBefore('/'),
                            color = Color.White,
                            fontSize = 17.sp,
                            modifier = Modifier.fillMaxWidth().clickable {
                                if (id !in zones) {
                                    zones = zones + id
                                    CityStore.save(ctx, zones)
                                }
                                adding = false
                            }.padding(horizontal = 16.dp, vertical = 14.dp),
                        )
                        HorizontalDivider(color = IosSep)
                    }
                }
            }
        }
    }
}
